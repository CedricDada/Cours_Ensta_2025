ffmpeg -framerate 10 -i Perroquet%04d.jpg perroquets.mp4
